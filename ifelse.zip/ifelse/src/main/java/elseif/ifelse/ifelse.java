package elseif.ifelse;

import java.util.Scanner;

public class ifelse {

    
    public static void main(String[] args) {
       
      Scanner teclado = new Scanner (System.in);
      
      int n;
      
        System.out.println("Digite o numero: ");
        n = teclado.nextInt();
        
        if (n % 2 == 0){
        System.out.println(+n+" é par");
        }
        else {
        System.out.println(+n+" é impar");
        }
     
        // -----------------------
        
        int ano;
        
        System.out.println("Digite o ano: ");
        ano = teclado.nextInt();
        
        if (ano == 2020){
            System.out.println(+ano+" é presente!");
        
        
        }
        
        else{
            
            if (ano > 2020){
                System.out.println(+ano+" é futuro!");
                }
       
            } 
 
            if (ano < 2020){
                System.out.println(+ano+" é passado!");
                
            }        
 
         // -----------------------
    
           String nome;
           double nota1, nota2, notaF;
           
           System.out.println("Digite seu nome: ");
           nome = teclado.next();
                    
           System.out.println("Digite a sua primeira nota: ");
           nota1 = teclado.nextDouble();
           
           System.out.println("Digite a sua segunda nota: ");
           nota2 = teclado.nextDouble();
           
           notaF = (nota1 + nota2) / 2;
           
           if
               (notaF <= 3.99) {
               System.out.println(nome+", sua média é: "+notaF+". Desculpe, você foi reprovado(a)");
                    }
           
           else{
               
               if 
                 
               (notaF >= 4 && notaF <= 5.99) {
               System.out.println(nome+", sua média é: "+notaF+". Desculpe, você está de recuperação");
               }
               
           }
           
            if 
                    (notaF >= 6){
                System.out.println(nome+", sua média é: "+notaF+". Parabéns! você foi aprovado(a)!");
            }
                
    
    }
    
}
