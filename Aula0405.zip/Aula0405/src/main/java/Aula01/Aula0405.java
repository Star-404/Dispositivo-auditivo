package Aula01;

import java.util.Scanner;
        
public class Aula0405 {

    public static void main(String[] args) {
       
        Scanner teclado = new Scanner (System.in);
                
        //Exercício 1
                
        String nome;
        
        System.out.println("Digite o seu nome: ");
        nome = teclado.next();
            
        System.out.println("Olá " +nome+ "! Seja bem vindo(a)!");
        System.out.println("\n");
            
         //Exercício 2
         
        double n1, n2, n3, n4, média;
         
        System.out.println("Digite a primeira nota: ");
        n1 = teclado.nextDouble();
         
        System.out.println("Digite a segunda nota: ");
        n2 = teclado.nextDouble();
         
        System.out.println("Digite a terceira nota: ");
        n3 = teclado.nextDouble();
         
        System.out.println("Digite a quarta nota: ");
        n4 = teclado.nextDouble();
         
        média = (n1 + n2 + n3 + n4)/4;
        
        System.out.println("Digite o seu nome: ");
        nome = teclado.next();
        
        System.out.println("a média de "+nome+" é: "+média+"");
        System.out.println("\n");
        //Exercício 3
        
        int x, y, z, a;
        
        System.out.println("Digite um numero: ");
        x = teclado.nextInt();
        y = 1;
        z = 0;
        
        while (y <= 10){
            z++;
            a = x * z;
            
        System.out.println(" "+x+" X "+y+" = "+a);
            y++;
        }
        System.out.println("\n ");
        
        //Exercício 4
        
        double areaT, areaQ, h, base, peso, lado, imc, altura;
        
        System.out.println("Digite o valor da base do triangulo: ");
        base = teclado.nextDouble();
            
        System.out.println("Digite o valor da altura do triangulo: ");
        h = teclado.nextDouble();
            
         areaT = (base * h)/2;
            
        System.out.println("A área do trinagulo é: "+areaT);
        System.out.println("\n");
            
        System.out.println("Digite o valor do lado do quadrado");
        lado = teclado.nextDouble();
            
        areaQ = lado * lado;
        System.out.println("A área do seu quadrado é: "+areaQ);
        System.out.println("\n");
            
        System.out.println("Digite seu peso em quilos: ");
        peso = teclado.nextDouble();
            
        System.out.println("Digite sua altura em metros: ");
        altura = teclado.nextDouble();
            
        imc = peso / (altura*2);
            
        System.out.println("IMC: "+imc);
        System.out.println("\n");
            
        //Exercício 5
        
        double km, m;
        
        System.out.println("Digite a quilometragem desejada para converção de milhas: ");
        km = teclado.nextDouble();
        
        m = km / 1.60934;
        
        System.out.println("Quilometragem convertida com sucesso! o valor é: "+m);
        
        System.out.println("\n");
        
        //Exercício 6
        
        int mês, dia;
        
        System.out.println("Digite quantos meses você quer para converter em dias: ");
        mês = teclado.nextInt();
        
        dia = mês * 30;
        
        System.out.println(""+mês+"meses em dias é: "+dia+" dias");
        
        
        //pergunta secreta do vídeo:
        //diferença entre Double e Float: Enquanto a variável Float ocupa menos espaço na Ram, a variável Double é muito mais precisa!
        
        
                
    }
    
}
